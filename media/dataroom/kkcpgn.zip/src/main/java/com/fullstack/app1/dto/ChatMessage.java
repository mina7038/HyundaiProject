package com.fullstack.app1.dto;

public record ChatMessage(String role, String content) {}
