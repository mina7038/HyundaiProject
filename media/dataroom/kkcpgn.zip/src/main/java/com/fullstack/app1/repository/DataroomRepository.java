package com.fullstack.app1.repository;

import com.fullstack.app1.entity.Dataroom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DataroomRepository extends JpaRepository<Dataroom, Long> {}
