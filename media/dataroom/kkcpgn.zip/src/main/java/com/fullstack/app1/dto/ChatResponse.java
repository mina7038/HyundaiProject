package com.fullstack.app1.dto;

public record ChatResponse(String text, String imageUrl) {}
